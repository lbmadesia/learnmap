import "./stylesheets/main.css";


import { ipcRenderer } from "electron";
import { firstpage,category } from "./scripts/pages";
import { categoryInit } from "./scripts/collections";
import env from "env";

const app =document.querySelector("#app");
// app.style.backgroundImage = "url('../resources/images/landpage.jpg')";
app.style.display = "block";
// app.innerHTML = firstpage();


// document.querySelector("#firstpage").addEventListener(
//   "click",
//   event => {
//   app.style.backgroundImage = "url('../resources/images/category.png')";
//   app.style.backgroundSize = "cover";
//   app.innerHTML=category();
//   categoryInit();
//   },
//   false
// );
