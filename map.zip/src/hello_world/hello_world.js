export const greet = () => {
  return "Hello World!";
};

export const bye = () => {
  return "See ya!";
};
