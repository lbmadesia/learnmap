export const firstpage = () => {
    return `<div id="firstpage">
    <div>
      <h1>MAP</h1>
      <p>
        Museum of Arts & Photography
      </p>
    </div>
  </div>`;
};

export const category = () => {
  return ` <div id="category">
  <div class="cat-div">
  <h1 style="color:#e68a00;text-align:center">Select The Collection</h1>
    <div class="cat-box" data-catname="modern and contemporary">
      <b>Modern and Contemporary</b>
    </div>
    <div class="cat-box" data-catname="painting">
      <b> Painting</b>
    </div>
    <div class="cat-box" data-catname="photography">
      <b>Photography</b>
    </div>
    <div class="cat-box" data-catname="popular arts">
      <b>Popular Arts</b>
    </div>
    <div class="cat-box" data-catname="sculptures and objects">
      <b>Sculptures and Objects</b>
    </div>
    <div class="cat-box" data-catname="textiles">
      <b>Textiles</b>
    </div>
  </div>
</div>`;
};