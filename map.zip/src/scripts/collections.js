



  export const categoryInit = ()=>{
   var catbox = document.getElementsByClassName("cat-box");
   for (let index = 0; index < catbox.length; index++) {
     catbox[index].addEventListener(
      "click",
      function(event){
        let catname = this.getAttribute('data-catname');
        console.log(catname);
      },
      false
    );
   }
    
   }


   function callajax(obj){

   }


